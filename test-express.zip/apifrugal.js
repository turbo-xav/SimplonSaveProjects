//L'application requiert l'utilisation du module Express.
//La variable express nous permettra d'utiliser les fonctionnalités du module Express.  
var express = require('express'); 

// Nous définissons ici les paramètres du serveur.
var hostname = 'localhost'; 
var port = 3000; 
 
var app = express(); 
var bodyParser = require("body-parser"); 
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

var helmet = require('helmet');
app.use(helmet());

var log4js = require('log4js');
log4js.configure({
	appenders: { cheese: { type: "file", filename: "log.txt" } },
	categories: { default: { appenders: ["cheese"], level: "error" } }
  });

var log = log4js.getLogger();
log.level = 'debug';
log.debug("My Debug message");

app.use(log4js.connectLogger(log, { level: process.env.LOG_LEVEL || 'info' }));

var session = require('express-session');
app.set('trust proxy', 1) // trust first proxy
var expiryDate = new Date( Date.now() + 60 * 60 * 1000 ); // 1 hour
app.use(session({
	name: 'session',
	keys: ['key1', 'key2'],
	cookie: { secure: true,
			  httpOnly: true,
			  domain: 'example.com',
			  path: 'foo/bar',
			  expires: expiryDate
			}
	})
  );

var myRouter = express.Router();
myRouter.route('/')
// all permet de prendre en charge toutes les méthodes. 
.all(function(req,res){ 
      res.json({message : "Bienvenue sur notre Frugal API ", methode : req.method});
});
// Je vous rappelle notre route (/piscines).  
myRouter.route('/piscines')
// J'implémente les méthodes GET, PUT, UPDATE et DELETE
// GET
// GET
.get(function(req,res){ 
	console.log(req.query.ville);
	res.json({
	message : "Liste les piscines de Lille Métropole avec paramètres :",
	ville : req.query.ville ? req.query.ville : 'pas de ville' ,
	nbResultat : req.query.maxresultat, 
	methode : req.method });
	
   })

//POST
.post(function(req,res){
 console.log(req.body)
	res.json({message : "Ajoute une nouvelle piscine à la liste", 
 nom : req.body.nom, 
 ville : req.body.ville, 
 taille : req.body.taille,
 methode : req.method});
})// ... code

myRouter.route('/piscines/:piscine_id')
.get(function(req,res){ 
	  res.json({message : "Vous souhaitez accéder aux informations de la piscine n°" + req.params.piscine_id});
})


//PUT
.put(function(req,res){ 
      res.json({message : "Mise à jour des informations d'une piscine dans la liste", methode : req.method});
})
//DELETE
.delete(function(req,res){ 
res.json({message : "Suppression d'une piscine dans la liste", methode : req.method});  
}); 
 
// Nous demandons à l'application d'utiliser notre routeur
app.use(myRouter); 

// Démarrer le serveur 
app.listen(port, hostname, function(){
	console.log("Mon serveur fonctionne sur http://"+ hostname +":"+port+"\n"); 
});